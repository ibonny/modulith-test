package personal.bonnycasi.modulithtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModulithTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
